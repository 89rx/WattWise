// backend/server.js
const express = require("express");
const path = require("path");
const mongoose = require("mongoose");
const multer = require("multer");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());
app.use("/backend/uploads", express.static(path.join(__dirname, "backend/uploads")));




// Connect to MongoDB
mongoose.connect("mongodb+srv://saranshmac90:Kxwn7s6G6pcIAOJQ@cluster0.rxdt8.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("Failed to connect to MongoDB", err));

// Artwork Schema
const artworkSchema = new mongoose.Schema({
  title: String,
  image: String,
  description: String,
  ratings: [{ type: Number, default: [] }], // Array to store individual ratings
});

// Add a virtual property to calculate the average rating
artworkSchema.virtual("averageRating").get(function () {
  if (this.ratings.length === 0) return 0; // If no ratings, return 0
  const sum = this.ratings.reduce((acc, rating) => acc + rating, 0); // Sum all ratings
  return (sum / this.ratings.length).toFixed(1); // Calculate average and round to 1 decimal place
});

// Enable virtuals in the schema
artworkSchema.set("toJSON", { virtuals: true });
artworkSchema.set("toObject", { virtuals: true });

const Artwork = mongoose.model("Artwork", artworkSchema);

// Upload Artwork
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, path.join(__dirname, "uploads"));
 // Ensure correct upload directory
  },
  filename: (_req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  },
});

const upload = multer({ storage });

app.post("/api/artworks", upload.single("image"), async (req, res) => {
  const { title, description } = req.body;
  const image = `/backend/uploads/${req.file.filename}`;


  const artwork = new Artwork({ title, image, description });
  await artwork.save();

  res.status(201).json(artwork);
});

// Get Artworks
app.get("/api/artworks", async (req, res) => {
  try {
    const artworks = await Artwork.find();
    res.status(200).json(artworks);
  } catch (error) {
    res.status(500).json({ message: "Error fetching artworks", error });
  }
});

// Delete Artwork
app.delete("/api/artworks/:id", async (req, res) => {
  try {
    const artwork = await Artwork.findByIdAndDelete(req.params.id);
    if (!artwork) {
      return res.status(404).json({ message: "Artwork not found" });
    }
    res.status(200).json({ message: "Artwork deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error deleting artwork", error });
  }
});

// Rate Artwork
app.post("/api/artworks/:id/rate", async (req, res) => {
  const { rating } = req.body;
  const { id } = req.params;

  try {
    const artwork = await Artwork.findById(id);
    if (!artwork) {
      return res.status(404).json({ message: "Artwork not found" });
    }

    // Add the new rating to the ratings array
    artwork.ratings.push(rating);
    await artwork.save();

    res.status(200).json({ message: "Rating submitted successfully", artwork });
  } catch (error) {
    res.status(500).json({ message: "Error submitting rating", error });
  }
});

const PORT = process.env.PORT || 3000; // Change to 3000 (default for cPanel)
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
